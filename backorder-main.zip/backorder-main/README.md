# Backorder
A machine learning model to predict if a product will be in backorder or not.

#